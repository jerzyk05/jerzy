from pathlib import Path
import urllib.request
from concurrent.futures import ThreadPoolExecutor
root=Path('.local/media')
root.mkdir(parents=True,exist_ok=True)
urls=[('sample-water.jpg','https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1600&q=85'),('sample-forest.jpg','https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=1600&q=85'),('sample-mountain.jpg','https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1600&q=85'),('sample-flower.mp4','https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4')]
def download(pair):
 name,url=pair
 urllib.request.urlretrieve(url,root/name)
 return name
with ThreadPoolExecutor(max_workers=4) as pool:
 print(list(pool.map(download,urls)))
