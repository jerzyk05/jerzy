import {runCLI} from '@wp-playground/cli';
import path from 'node:path';
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import net from 'node:net';
const listen=net.Server.prototype.listen;
net.Server.prototype.listen=function(...args){if(typeof args[0]==='number'){args=[{port:args[0],host:'127.0.0.1'},...args.slice(1).filter(x=>typeof x!=='string')];}return listen.apply(this,args)};
const root=path.resolve(import.meta.dirname,'..');
const site=path.join(root,'.local/wordpress');
await fs.mkdir(site,{recursive:true});
await fs.mkdir(path.join(root,'.local/media'),{recursive:true});
const first=!(await fs.stat(path.join(site,'wp-load.php')).catch(()=>null));
const password=crypto.randomBytes(30).toString('base64url');
const server=await runCLI({command:'server',port:8770,php:'8.3',wp:'latest',workers:1,login:true,
    wordpressInstallMode:first?'download-and-install':'install-from-existing-files-if-needed',
    'define-bool':[['DISABLE_WP_CRON',true]],
    'mount-before-install':[{hostPath:site,vfsPath:'/wordpress'},{hostPath:path.join(root,'.local/media'),vfsPath:'/jerzy-private-media'}],
    mount:[{hostPath:path.join(root,'wordpress/jerzy-gallery'),vfsPath:'/wordpress/wp-content/plugins/jerzy-gallery'},{hostPath:path.join(root,'wordpress/jerzy-journal'),vfsPath:'/wordpress/wp-content/themes/jerzy-journal'}],
    blueprint:{steps:[{step:'activatePlugin',pluginPath:'jerzy-gallery/jerzy-gallery.php'},{step:'activateTheme',themeFolderName:'jerzy-journal'},{step:'setSiteOptions',options:{blogname:'Jerzy — Life, collected',blogdescription:'Photos, films and stories / Zdjęcia, filmy i historie',blog_public:'0',jl_demo:'1'}},
    {step:'runPHP',code:`<?php require '/wordpress/wp-load.php'; ini_set('upload_max_filesize','100M'); $u=get_user_by('login','admin'); if($u){wp_set_password('${password}',$u->ID);} update_option('default_comment_status','closed'); update_option('users_can_register',0);`}]
    }});
// Keep the local admin password in process memory; never save it in source or logs.
await fs.writeFile(path.join(root,'.local/ready.json'),JSON.stringify({url:server.serverUrl,ready:true}));
console.log('Local preview: '+server.serverUrl+' (automatic owner sign-in on this computer only). No changes are sent to Hostinger.');
process.stdin.setEncoding('utf8');
process.stdin.on('data',async data=>{for(const line of data.trim().split('\n')){try{if(line==='seed'){const r=await server.playground.run({code:await fs.readFile(path.join(root,'scripts/seed-demo.php'),'utf8')});console.log(r.text);}else if(line==='test'){const {test}=await import('../tests/integration.mjs?'+Date.now());await test({server,password,root});}else if(line==='check'){const result=await server.playground.run({code:await fs.readFile(path.join(root,'tests/check.php'),'utf8')});console.log(result.text);}}catch(error){console.error(error.message);}}});
