<?php
require '/wordpress/wp-load.php';
if(get_option('jl_demo_seeded')){echo 'Demo seed already present.';return;}
$dir=jl_storage();if(is_wp_error($dir))die($dir->get_error_message());
$albums=get_posts(['post_type'=>'jl_album','post_status'=>'publish','numberposts'=>-1,'orderby'=>'ID','order'=>'ASC']);
$samples=['sample-water.jpg'=>['By the water','Nad wodą'],'sample-forest.jpg'=>['Forest light','Światło w lesie'],'sample-mountain.jpg'=>['An open horizon','Otwarty horyzont']];
$hero=0;$n=0;
foreach($albums as $album){
    foreach($samples as $file=>$names){
        $key=wp_generate_uuid4().'.jpg';copy($dir.'/'.$file,$dir.'/'.$key);
        $id=wp_insert_post(['post_type'=>'jl_item','post_title'=>$names[0],'post_status'=>'publish','post_parent'=>$album->ID,'post_content'=>'Illustrative sample photograph from Unsplash, not a photograph from this country. Replace it with your own media.','comment_status'=>'open','menu_order'=>$n++]);
        foreach(['_jl_title_pl'=>$names[1],'_jl_body_pl'=>'Przykładowe zdjęcie z Unsplash. Nie przedstawia tego kraju. Zastąp je własnym zdjęciem.','_jl_file'=>$key,'_jl_kind'=>'photo','_jl_mime'=>'image/jpeg','_jl_sample'=>'1'] as $k=>$v)update_post_meta($id,$k,$v);
        if(!$hero)$hero=$id;
        $editor=wp_get_image_editor($dir.'/'.$key);if(!is_wp_error($editor)){$editor->resize(700,700,false);$result=$editor->save($dir.'/thumb-'.$key);if(!is_wp_error($result))update_post_meta($id,'_jl_thumb',basename($result['path']));}
    }
    $file=wp_generate_uuid4().'.mp4';copy($dir.'/sample-flower.mp4',$dir.'/'.$file);
    $id=wp_insert_post(['post_type'=>'jl_item','post_title'=>'A moment outdoors','post_status'=>'publish','post_parent'=>$album->ID,'post_content'=>'Illustrative flower video from MDN (CC0), not footage from this country.']);
    foreach(['_jl_title_pl'=>'Chwila na łonie natury','_jl_body_pl'=>'Przykładowy film z kwiatami z MDN (CC0). Nie jest to nagranie z tego kraju.','_jl_file'=>$file,'_jl_kind'=>'video','_jl_mime'=>'video/mp4','_jl_poster'=>$hero,'_jl_sample'=>'1'] as $k=>$v)update_post_meta($id,$k,$v);
}
update_option('jl_hero',$hero);
$story=wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>'The beauty of taking the slow road','post_content'=>'Some days are better without an itinerary. A quiet path, a turn toward the water, a little extra time to watch the light change. A photograph can hold the view. A few words can keep the feeling that went with it.\n\nIllustrative writing for design review, not an account of a real event.']);
update_post_meta($story,'_jl_title_pl','Urok niespiesznej podróży');update_post_meta($story,'_jl_body_pl','Niektóre dni są lepsze bez planu. Spokojna ścieżka, skręt w stronę wody, chwila dłużej, by popatrzeć na zmieniające się światło. Zdjęcie może zachować widok. Kilka słów pozwala zatrzymać towarzyszące mu uczucie.\n\nPrzykładowy tekst do oceny projektu, nie opis rzeczywistego wydarzenia.');
wp_delete_post(1,true);wp_delete_post(2,true);
update_option('jl_demo_seeded','1');echo 'Seeded 10 albums, 30 sample photos, 10 sample videos and one bilingual story.';
