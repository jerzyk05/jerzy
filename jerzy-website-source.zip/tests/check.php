<?php
require '/wordpress/wp-load.php';
$errors=[];$files=0;
foreach(['/wordpress/wp-content/plugins/jerzy-gallery','/wordpress/wp-content/themes/jerzy-journal'] as $dir){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir)) as $f){if($f->getExtension()!=='php')continue;try{token_get_all(file_get_contents($f->getPathname()),TOKEN_PARSE);$files++;}catch(ParseError $e){$errors[]=$f->getPathname().': '.$e->getMessage();}}}
echo json_encode(['php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version'),'syntax_files'=>$files,'errors'=>$errors,'album_count'=>count(jl_albums()),'media_count'=>count(jl_items()),'gd'=>extension_loaded('gd'),'upload_max_filesize'=>ini_get('upload_max_filesize'),'post_max_size'=>ini_get('post_max_size')]);
