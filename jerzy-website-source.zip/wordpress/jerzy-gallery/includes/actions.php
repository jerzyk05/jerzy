<?php
defined('ABSPATH') || exit;
function jl_error($message,$status=400) { wp_die(esc_html($message),'Jerzy Gallery',['response'=>$status,'back_link'=>true]); }
function jl_nonce($action) { if(!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])),$action)) jl_error('This form expired. Reload the page and try again.',403); }
function jl_rate($bucket,$max) {
    $key='jl_rate_'.hash_hmac('sha256',$bucket.'|'.($_SERVER['REMOTE_ADDR']??''),wp_salt());
    $count=(int)get_transient($key);if($count>=$max) jl_error('Please wait an hour before trying again.',429);
    set_transient($key,$count+1,HOUR_IN_SECONDS);
}
function jl_admin_redirect($message='Saved') { wp_safe_redirect(add_query_arg(['page'=>'jerzy-gallery','message'=>$message],admin_url('admin.php'))); exit; }
function jl_embed_url($url) {
    $parts=wp_parse_url($url); if(!$parts || ($parts['scheme']??'')!=='https') return '';
    $host=strtolower($parts['host']??''); $path=$parts['path']??'';
    if(in_array($host,['youtube.com','www.youtube.com','youtu.be'],true)) {
        parse_str($parts['query']??'',$q);$id=$host==='youtu.be'?trim($path,'/'):($q['v']??'');
        return preg_match('/^[A-Za-z0-9_-]{11}$/',$id)?'https://www.youtube-nocookie.com/embed/'.$id:'';
    }
    if(in_array($host,['vimeo.com','www.vimeo.com'],true) && preg_match('~^/(\d+)(?:/([A-Za-z0-9]+))?/?$~',$path,$m)) return 'https://player.vimeo.com/video/'.$m[1].(!empty($m[2])?'?h='.$m[2]:'');
    return '';
}
add_action('admin_post_jl_manage',function(){
    if(!jl_owner()) jl_error('Owner access required.',403); jl_nonce('jl_manage');
    $op=sanitize_key($_POST['op']??'');
    if($op==='album') {
        $title=sanitize_text_field(wp_unslash($_POST['title']??''));if(!$title)jl_error('Enter an album name.');
        $parent=absint($_POST['parent']??0);if($parent && get_post_type($parent)!=='jl_album')jl_error('Invalid parent album.');
        $id=wp_insert_post(['post_type'=>'jl_album','post_title'=>$title,'post_status'=>($_POST['visibility']??'')==='private'?'private':'publish','post_parent'=>$parent],true);
        if(is_wp_error($id))jl_error($id->get_error_message());update_post_meta($id,'_jl_title_pl',sanitize_text_field(wp_unslash($_POST['title_pl']??'')));
    } elseif($op==='upload') {
        $album=absint($_POST['album']??0);if(get_post_type($album)!=='jl_album')jl_error('Choose an album first.');
        $files=$_FILES['media']??null;if(!$files || !is_array($files['name']))jl_error('Choose files.');
        if(count($files['name'])>30)jl_error('Upload up to 30 files at a time.');
        $errors=[];$saved=0;
        foreach($files['name'] as $i=>$name) {$f=[];foreach(['name','tmp_name','type','size','error'] as $key)$f[$key]=$files[$key][$i];$result=jl_store_upload($f,$album);if(is_wp_error($result))$errors[]=sanitize_file_name($name).': '.$result->get_error_message();else $saved++;}
        jl_admin_redirect($saved.' files saved as drafts. '.implode(' ',$errors));
    } elseif($op==='external') {
        $album=absint($_POST['album']??0);$embed=jl_embed_url(esc_url_raw(wp_unslash($_POST['url']??'')));
        if(get_post_type($album)!=='jl_album' || !$embed)jl_error('Choose an album and enter a YouTube or Vimeo HTTPS video link.');
        if(get_post_status($album)!=='publish')jl_error('Use direct uploads for private albums. External videos have their own privacy settings.');
        $id=wp_insert_post(['post_type'=>'jl_item','post_status'=>'draft','post_parent'=>$album,'post_title'=>sanitize_text_field(wp_unslash($_POST['title']??'Video'))],true);
        if(is_wp_error($id))jl_error($id->get_error_message());update_post_meta($id,'_jl_kind','video');update_post_meta($id,'_jl_embed',$embed);
    } elseif($op==='settings') {
        $color=sanitize_hex_color(wp_unslash($_POST['background']??''));if(!$color)jl_error('Choose a valid color.');
        update_option('jl_background',$color);update_option('jl_guest_enabled',isset($_POST['guest_enabled'])?'1':'0');
        update_option('jl_hero',absint($_POST['hero']??0));
        foreach(['intro_en','intro_pl','about_en','about_pl'] as $field) update_option('jl_'.$field,sanitize_textarea_field(wp_unslash($_POST[$field]??'')));
    } elseif($op==='order') {
        $album=absint($_POST['album']??0);if(get_post_type($album)!=='jl_album')jl_error('Invalid album.');
        $ids=array_filter(array_map('absint',explode(',',sanitize_text_field(wp_unslash($_POST['order']??'')))));
        foreach($ids as $index=>$id) { $p=get_post($id);if($p && $p->post_type==='jl_item' && $p->post_parent===$album)wp_update_post(['ID'=>$id,'menu_order'=>$index]);}
        $cover=absint($_POST['cover']??0);$p=get_post($cover);if(!$cover || ($p && $p->post_type==='jl_item' && $p->post_parent===$album && get_post_meta($cover,'_jl_kind',true)==='photo'))update_post_meta($album,'_jl_cover',$cover);
    }
    jl_admin_redirect();
});
function jl_guest_submit() {
    jl_nonce('jl_guest'); if(get_option('jl_guest_enabled','1')!=='1')jl_error('Guest submissions are paused.',403);
    if(!empty($_POST['website']))jl_error('Unable to submit.',400);jl_rate('guest',6);
    $name=sanitize_text_field(wp_unslash($_POST['visitor_name']??''));$caption=sanitize_textarea_field(wp_unslash($_POST['caption']??''));
    if(!$name || strlen($name)>240 || strlen($caption)>6000 || empty($_POST['consent']))jl_error('Enter your name and confirm permission to share.');
    $files=$_FILES['media']??null;if(!$files || !is_array($files['name']) || count($files['name'])>6)jl_error('Choose between 1 and 6 files.');
    $errors=[];$saved=0;
    foreach($files['name'] as $i=>$filename) {$f=[];foreach(['name','tmp_name','type','size','error'] as $key)$f[$key]=$files[$key][$i];$result=jl_store_upload($f,0,true,$name,$caption);if(is_wp_error($result))$errors[]=$result->get_error_message();else $saved++;}
    if(!$saved)jl_error(implode(' ',$errors));
    $url=jl_link('guest',0,($_POST['lang']??'')==='pl'?'pl':'en');
    wp_safe_redirect(add_query_arg(['submitted'=>$saved,'failed'=>count($errors)],$url));exit;
}
add_action('admin_post_nopriv_jl_guest','jl_guest_submit');add_action('admin_post_jl_guest','jl_guest_submit');
function jl_comment_submit() {
    jl_nonce('jl_comment');$id=absint($_POST['media_id']??0);$p=get_post($id);
    if(!$p || $p->post_type!=='jl_item' || $p->post_status!=='publish' || !jl_visible($p) || get_post_meta($id,'_jl_kind',true)!=='photo')jl_error('Photo unavailable.',404);
    if(!empty($_POST['website']))jl_error('Unable to submit.');jl_rate('comment',12);
    $name=sanitize_text_field(wp_unslash($_POST['visitor_name']??''));$body=sanitize_textarea_field(wp_unslash($_POST['comment']??''));
    if(!$name || !$body || strlen($name)>240 || strlen($body)>12000)jl_error('Enter your name and a comment (up to 3,000 characters).');
    $result=wp_insert_comment(['comment_post_ID'=>$id,'comment_author'=>$name,'comment_content'=>$body,'comment_approved'=>0,'comment_type'=>'comment']);
    if(!$result)jl_error('The comment could not be saved.');
    wp_safe_redirect(add_query_arg('comment_sent','1',jl_link('media',$id,($_POST['lang']??'')==='pl'?'pl':'en')).'#comments');exit;
}
add_action('admin_post_nopriv_jl_comment','jl_comment_submit');add_action('admin_post_jl_comment','jl_comment_submit');
