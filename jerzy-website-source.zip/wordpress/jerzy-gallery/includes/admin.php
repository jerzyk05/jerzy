<?php
defined('ABSPATH') || exit;
add_action('admin_menu',function(){add_menu_page('My collection / Moja kolekcja','My collection','manage_options','jerzy-gallery','jl_dashboard','dashicons-camera',3);});
add_action('add_meta_boxes',function(){
    foreach(['jl_album','jl_item','post','page'] as $type)add_meta_box('jl_translation','Polish version / Wersja polska','jl_translation_box',$type,'normal','high');
    add_meta_box('jl_item_details','Media details / Szczegóły','jl_item_box','jl_item','normal','high');
});
function jl_translation_box($p) {
    wp_nonce_field('jl_metadata','jl_metadata_nonce');
    echo '<p>The main title and body are English. Add Polish below; an empty field uses English.</p><p><label>Polish title / Tytuł polski<br><input class="widefat" name="jl_title_pl" value="'.esc_attr(get_post_meta($p->ID,'_jl_title_pl',true)).'"></label></p><p><label>Polish body / Treść polska<br><textarea class="widefat" rows="8" name="jl_body_pl">'.esc_textarea(get_post_meta($p->ID,'_jl_body_pl',true)).'</textarea></label></p>';
}
function jl_item_box($p) {
    echo '<p><label>Album <select name="jl_album"><option value="0">Guest Gallery / Galeria gości</option>';
    foreach(jl_albums() as $a)echo '<option value="'.$a->ID.'" '.selected($p->post_parent,$a->ID,false).'>'.esc_html($a->post_title).'</option>';
    echo '</select></label></p><p>Visibility: drafts are owner-only; Publish makes an item visible if its album is public. Pending guest uploads require your review.</p>';
    echo '<p><a target="_blank" rel="noopener" href="'.esc_url(jl_link('media',$p->ID)).'">Preview this item / Podgląd</a></p>';
    if(get_post_meta($p->ID,'_jl_guest',true))echo '<p>Submitted by / Autor: '.esc_html(get_post_meta($p->ID,'_jl_guest_name',true)).'</p>';
    echo '<p><label>Category / Kategoria <input name="jl_category" value="'.esc_attr(get_post_meta($p->ID,'_jl_category',true)).'"></label></p>';
    echo '<p><label>Video poster photo / Zdjęcie okładki filmu <select name="jl_poster"><option value="0">None / Brak</option>';
    foreach(jl_items(0,'photo') as $item)echo '<option value="'.$item->ID.'" '.selected(get_post_meta($p->ID,'_jl_poster',true),$item->ID,false).'>'.esc_html($item->post_title).'</option>';
    echo '</select></label></p>';
}
add_action('save_post',function($id,$post){
    if(!jl_owner() || wp_is_post_revision($id) || (defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE) || !isset($_POST['jl_metadata_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['jl_metadata_nonce'])),'jl_metadata'))return;
    update_post_meta($id,'_jl_title_pl',sanitize_text_field(wp_unslash($_POST['jl_title_pl']??'')));
    update_post_meta($id,'_jl_body_pl',wp_kses_post(wp_unslash($_POST['jl_body_pl']??'')));
    if($post->post_type==='jl_item') {
        update_post_meta($id,'_jl_category',sanitize_text_field(wp_unslash($_POST['jl_category']??'')));
        $poster=absint($_POST['jl_poster']??0);if(!$poster || (get_post_type($poster)==='jl_item' && get_post_meta($poster,'_jl_kind',true)==='photo'))update_post_meta($id,'_jl_poster',$poster);
        $parent=absint($_POST['jl_album']??0);
        if(($parent && get_post_type($parent)==='jl_album') || (!$parent && get_post_meta($id,'_jl_guest',true))) {
            global $wpdb;$wpdb->update($wpdb->posts,['post_parent'=>$parent],['ID'=>$id],['%d'],['%d']);clean_post_cache($id);
        }
    }
},10,2);
function jl_form_start($op,$multipart=false) {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" '.($multipart?'enctype="multipart/form-data"':'').'>';wp_nonce_field('jl_manage');echo '<input type="hidden" name="action" value="jl_manage"><input type="hidden" name="op" value="'.esc_attr($op).'">';}
function jl_album_select($name='album') {echo '<select name="'.esc_attr($name).'" required><option value="">Choose album / Wybierz album</option>';foreach(jl_albums() as $a)echo '<option value="'.$a->ID.'">'.esc_html($a->post_title).' ('.esc_html($a->post_status).')</option>';echo '</select>';}
function jl_dashboard() {
    if(!jl_owner())return;
    echo '<div class="wrap jl-admin"><h1>My collection / Moja kolekcja</h1><p>Photos, films and stories — managed in one place. / Zdjęcia, filmy i historie w jednym miejscu.</p>';
    if(isset($_GET['message']))echo '<div class="notice notice-success"><p>'.esc_html(sanitize_text_field(wp_unslash($_GET['message']))).'</p></div>';
    echo '<p><a class="button" href="'.esc_url(home_url('/')).'">View website / Zobacz stronę</a> <a class="button" href="'.esc_url(admin_url('edit.php?post_type=jl_item&post_status=pending')).'">Review guest submissions / Zgłoszenia gości</a> <a class="button" href="'.esc_url(admin_url('edit-comments.php?comment_status=moderated')).'">Review comments / Komentarze</a> <a class="button" href="'.esc_url(admin_url('post-new.php')).'">Write a story / Napisz wpis</a> <a class="button" href="'.esc_url(admin_url('post-new.php?post_type=page')).'">Add a page / Dodaj stronę</a></p>';
    echo '<div class="jl-admin-grid"><section><h2>Create an album / Utwórz album</h2>';jl_form_start('album');
    echo '<label>English name <input name="title" required maxlength="150"></label><label>Polska nazwa <input name="title_pl" maxlength="150"></label><label>Visibility / Widoczność <select name="visibility"><option value="public">Public / Publiczny</option><option value="private">Private: owner only / Prywatny</option></select></label><label>Parent album / Album nadrzędny <select name="parent"><option value="0">None / Brak</option>';
    foreach(jl_albums() as $a)echo '<option value="'.$a->ID.'">'.esc_html($a->post_title).'</option>';
    echo '</select></label><button class="button button-primary">Create album / Utwórz</button></form></section>';
    echo '<section><h2>Upload photos & videos / Dodaj media</h2>';jl_form_start('upload',true);jl_album_select();
    echo '<label class="jl-drop">Choose or drop files here / Wybierz lub upuść pliki<input type="file" name="media[]" multiple required accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"></label><p>Up to 30 files per batch. Photos: 20 MB. Videos: 100 MB. Server request limit: '.esc_html(ini_get('post_max_size')).'. New media saves as a draft for your review.</p><button class="button button-primary">Save uploads / Zapisz pliki</button></form></section>';
    echo '<section><h2>Add a hosted video / Dodaj film z serwisu</h2>';jl_form_start('external');jl_album_select();echo '<label>Title / Tytuł<input name="title" required></label><label>YouTube or Vimeo link<input type="url" name="url" required placeholder="https://..."></label><p>For public galleries. The video provider controls playback privacy. Private albums should use direct uploads.</p><button class="button button-primary">Add video draft / Dodaj szkic filmu</button></form></section>';
    echo '<section><h2>Website settings / Ustawienia strony</h2>';jl_form_start('settings');
    echo '<label>Homepage background / Tło strony głównej<input type="color" name="background" value="'.esc_attr(get_option('jl_background','#C5BDAB')).'"></label><p>Choose a light background for the approved black typography.</p><label>Homepage photograph / Zdjęcie główne<select name="hero"><option value="0">First public photograph / Pierwsze publiczne zdjęcie</option>';
    foreach(jl_items(0,'photo') as $p)echo '<option value="'.$p->ID.'" '.selected(get_option('jl_hero'),$p->ID,false).'>'.esc_html($p->post_title).'</option>';
    echo '</select></label><label><input type="checkbox" name="guest_enabled" value="1" '.checked(get_option('jl_guest_enabled','1'),'1',false).'> Accept guest uploads / Przyjmuj zgłoszenia gości</label>';
    foreach(['intro_en'=>'Homepage introduction (English)','intro_pl'=>'Wprowadzenie (polski)','about_en'=>'About (English)','about_pl'=>'O mnie (polski)'] as $key=>$label)echo '<label>'.esc_html($label).'<textarea name="'.esc_attr($key).'" rows="3">'.esc_textarea(get_option('jl_'.$key,'')).'</textarea></label>';
    echo '<button class="button button-primary">Save settings / Zapisz ustawienia</button></form></section></div>';
    echo '<h2>Albums / Albumy</h2><p>Drag items to rearrange them, or use the up/down buttons, then save. Use Edit for bilingual captions and publishing.</p>';
    foreach(jl_albums() as $a) {
        echo '<details class="jl-album"><summary>'.esc_html($a->post_title).' — '.esc_html($a->post_status).'</summary><p><a href="'.esc_url(get_edit_post_link($a->ID)).'">Edit name, description, visibility or move to Trash / Edytuj album</a> · <a href="'.esc_url(jl_link('albums',$a->ID)).'">Preview / Podgląd</a></p>';
        $items=jl_items($a->ID);jl_form_start('order');echo '<input type="hidden" name="album" value="'.$a->ID.'"><input type="hidden" name="order" value="'.esc_attr(implode(',',wp_list_pluck($items,'ID'))).'"><label>Cover / Okładka<select name="cover"><option value="0">Automatic / Automatyczna</option>';
        foreach($items as $item)if(get_post_meta($item->ID,'_jl_kind',true)==='photo')echo '<option value="'.$item->ID.'" '.selected(get_post_meta($a->ID,'_jl_cover',true),$item->ID,false).'>'.esc_html($item->post_title).'</option>';
        echo '</select></label><ol class="jl-sort">';
        foreach($items as $item)echo '<li draggable="true" data-id="'.$item->ID.'"><span>'.esc_html($item->post_title).' · '.esc_html($item->post_status).'</span> <button type="button" class="button" data-move="up" aria-label="Move up">↑</button> <button type="button" class="button" data-move="down" aria-label="Move down">↓</button> <a href="'.esc_url(get_edit_post_link($item->ID)).'">Edit / Edytuj</a></li>';
        echo '</ol><button class="button button-primary">Save cover & order / Zapisz</button></form></details>';
    }
    echo '</div>';
}
add_action('admin_enqueue_scripts',function($hook){
    if($hook!=='toplevel_page_jerzy-gallery')return;
    wp_enqueue_style('jl-admin',plugins_url('assets/admin.css',dirname(__FILE__)),[], '1.0.0');
    wp_enqueue_script('jl-admin',plugins_url('assets/admin.js',dirname(__FILE__)),[], '1.0.0',true);
});
