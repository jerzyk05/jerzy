<?php
defined('ABSPATH') || exit;
function jl_lang() { return isset($_GET['lang']) && $_GET['lang'] === 'pl' ? 'pl' : 'en'; }
function jl_t($en, $pl) { return jl_lang() === 'pl' ? $pl : $en; }
function jl_title($p) { $p=get_post($p); if(!$p) return ''; return jl_lang()==='pl' ? (get_post_meta($p->ID,'_jl_title_pl',true) ?: $p->post_title) : $p->post_title; }
function jl_body($p) { $p=get_post($p); if(!$p) return ''; return jl_lang()==='pl' ? (get_post_meta($p->ID,'_jl_body_pl',true) ?: $p->post_content) : $p->post_content; }
function jl_link($view='home',$id=0,$lang=null) { $q=['view'=>$view,'lang'=>$lang ?: jl_lang()]; if($id) $q['entry']=(int)$id; return add_query_arg($q,home_url('/')); }
function jl_owner() { return current_user_can('manage_options'); }
function jl_visible($p,$seen=[]) {
    $p=get_post($p); if(!$p || in_array($p->ID,$seen,true) || in_array($p->post_status,['trash','auto-draft'],true)) return false;
    if(jl_owner()) return true;
    if($p->post_status!=='publish' || $p->post_password) return false;
    if(in_array($p->post_type,['jl_album','jl_item'],true) && $p->post_parent) {
        $seen[]=$p->ID; $parent=get_post($p->post_parent);
        return $parent && $parent->post_type==='jl_album' && jl_visible($parent,$seen);
    }
    return true;
}
function jl_albums() { return array_values(array_filter(get_posts(['post_type'=>'jl_album','post_status'=>jl_owner()?['publish','private','draft']:['publish'],'numberposts'=>-1,'orderby'=>'menu_order title','order'=>'ASC']), 'jl_visible')); }
function jl_items($album=0,$kind='',$guest=false) {
    $args=['post_type'=>'jl_item','post_status'=>jl_owner()&&!$guest?['publish','private','draft']:['publish'],'numberposts'=>-1,'orderby'=>'menu_order ID','order'=>'ASC'];
    $meta=[]; if($album) $args['post_parent']=$album;
    if($kind) $meta[]=['key'=>'_jl_kind','value'=>$kind];
    if($guest) $meta[]=['key'=>'_jl_guest','value'=>'1'];
    if($meta) $args['meta_query']=$meta;
    return array_values(array_filter(get_posts($args),'jl_visible'));
}
function jl_file_url($id,$size='full') { return add_query_arg(['jl_media'=>(int)$id,'size'=>$size],home_url('/')); }
function jl_cover($album) {
    $cover=(int)get_post_meta($album->ID,'_jl_cover',true); $p=get_post($cover);
    if($p && $p->post_type==='jl_item' && $p->post_parent===$album->ID && jl_visible($p) && get_post_meta($cover,'_jl_kind',true)==='photo') return jl_file_url($cover,'thumb');
    $items=jl_items($album->ID,'photo'); return $items ? jl_file_url($items[0]->ID,'thumb') : '';
}
add_action('init',function(){
    foreach(['jl_album'=>['Albums / Albumy','dashicons-images-alt2',true],'jl_item'=>['Photos & videos / Media','dashicons-format-gallery',false]] as $type=>$cfg) {
        register_post_type($type,['label'=>$cfg[0],'public'=>false,'show_ui'=>true,'show_in_menu'=>true,'show_in_rest'=>false,'hierarchical'=>$cfg[2],'menu_icon'=>$cfg[1], 'supports'=>['title','editor','page-attributes','revisions','comments'], 'capabilities'=>array_fill_keys(['edit_post','read_post','delete_post','edit_posts','edit_others_posts','publish_posts','read_private_posts','delete_posts','delete_private_posts','delete_published_posts','delete_others_posts','edit_private_posts','edit_published_posts','create_posts'],'manage_options'),'map_meta_cap'=>false]);
    }
});
function jl_activate() {
    if(get_option('jl_initialized')) return;
    $countries=['Guatemala'=>'Gwatemala','Honduras'=>'Honduras','Taiwan'=>'Tajwan','Sweden'=>'Szwecja','Costa Rica'=>'Kostaryka','Hong Kong'=>'Hongkong','Poland'=>'Polska','Mexico'=>'Meksyk','Italy'=>'Włochy','Romania'=>'Rumunia'];
    foreach($countries as $en=>$pl) { $id=wp_insert_post(['post_type'=>'jl_album','post_status'=>'publish','post_title'=>$en]); if($id) update_post_meta($id,'_jl_title_pl',$pl); }
    add_option('jl_background','#C5BDAB'); add_option('jl_guest_enabled','1'); add_option('jl_initialized','1');
}
add_filter('post_type_link',function($url,$post){return $post->post_type==='jl_album'?jl_link('albums',$post->ID):($post->post_type==='jl_item'?jl_link('media',$post->ID):$url);},10,2);
add_filter('preview_post_link',function($url,$post){return in_array($post->post_type,['jl_item','jl_album'])?jl_link($post->post_type==='jl_item'?'media':'albums',$post->ID):$url;},10,2);
add_filter('pre_comment_approved',function($approved,$data){return get_post_type($data['comment_post_ID'])==='jl_item' ? 0 : $approved;},10,2);
add_filter('comments_open',function($open,$id){return get_post_type($id)==='jl_item' ? (get_post_meta($id,'_jl_kind',true)==='photo' && jl_visible($id)) : $open;},10,2);
