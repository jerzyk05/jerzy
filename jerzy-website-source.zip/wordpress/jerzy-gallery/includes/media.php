<?php
defined('ABSPATH') || exit;
function jl_storage() {
    $dir=defined('JL_MEDIA_DIR') ? JL_MEDIA_DIR : dirname(rtrim(ABSPATH,'/\\')).'/jerzy-private-media';
    if(!is_dir($dir) && !wp_mkdir_p($dir)) return new WP_Error('storage','Private storage is unavailable. Configure JL_MEDIA_DIR outside public_html.');
    $real=realpath($dir); $root=realpath(ABSPATH);
    if(!$real || !$root || str_starts_with(wp_normalize_path($real).'/',wp_normalize_path($root).'/')) return new WP_Error('storage','Private media must be stored outside the website document root.');
    return $real;
}
function jl_store_upload($f,$album,$guest=false,$name='',$caption='') {
    if(!isset($f['error']) || $f['error']!==UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) return new WP_Error('upload','Upload failed. Check the file size and server limit.');
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION)); $types=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','mp4'=>'video/mp4','webm'=>'video/webm'];
    if(!isset($types[$ext])) return new WP_Error('type','Use JPG, PNG, WebP, MP4 or WebM.');
    $kind=in_array($ext,['mp4','webm'],true)?'video':'photo'; $limit=($kind==='photo'?20:100)*MB_IN_BYTES;
    if(filesize($f['tmp_name'])>$limit || filesize($f['tmp_name'])<1) return new WP_Error('size','File exceeds the upload size limit.');
    if($kind==='photo') {
        $info=@getimagesize($f['tmp_name']);
        if(!$info || ($info['mime']??'')!==$types[$ext] || $info[0]*$info[1]>80000000) return new WP_Error('image','Invalid image or image above 80 megapixels.');
    } else {
        require_once ABSPATH.'wp-admin/includes/media.php';
        $meta=wp_read_video_metadata($f['tmp_name']);
        if(!$meta || empty($meta['length']) || empty($meta['width']) || empty($meta['height'])) return new WP_Error('video','Cannot verify this video. Export an MP4 or WebM file.');
        if($guest && $meta['length']>60) return new WP_Error('length','Guest videos must be 60 seconds or shorter.');
        require_once ABSPATH.WPINC.'/ID3/getid3.php'; $id3=new getID3(); $probe=$id3->analyze($f['tmp_name']);
        if(!in_array($probe['mime_type']??'',['video/mp4','video/webm','video/x-matroska'],true)) return new WP_Error('video','The file contents are not a supported video.');
    }
    $dir=jl_storage(); if(is_wp_error($dir)) return $dir;
    $key=wp_generate_uuid4().'.'.$ext; $path=$dir.'/'.$key;
    if(!move_uploaded_file($f['tmp_name'],$path)) return new WP_Error('write','The media file could not be saved.');
    $id=wp_insert_post(['post_type'=>'jl_item','post_status'=>$guest?'pending':'draft','post_parent'=>(int)$album,'post_title'=>sanitize_text_field(pathinfo($f['name'],PATHINFO_FILENAME)),'post_content'=>sanitize_textarea_field($caption),'comment_status'=>$kind==='photo'?'open':'closed'],true);
    if(is_wp_error($id)) {unlink($path); return $id;}
    update_post_meta($id,'_jl_file',$key); update_post_meta($id,'_jl_mime',$types[$ext]); update_post_meta($id,'_jl_kind',$kind);
    if($guest) {update_post_meta($id,'_jl_guest','1'); update_post_meta($id,'_jl_guest_name',sanitize_text_field($name));}
    if($kind==='photo') {
        $editor=wp_get_image_editor($path);
        if(!is_wp_error($editor)) {
            $editor->resize(1920,1920,false); $editor->set_quality(85); $result=$editor->save($dir.'/full-'.$key);
            if(!is_wp_error($result)) update_post_meta($id,'_jl_full',basename($result['path']));
            $editor=wp_get_image_editor($path);
            if(!is_wp_error($editor)) {$editor->resize(700,700,false); $editor->set_quality(80); $result=$editor->save($dir.'/thumb-'.$key); if(!is_wp_error($result)) update_post_meta($id,'_jl_thumb',basename($result['path']));}
        }
    }
    return $id;
}
add_action('template_redirect',function(){
    if(!isset($_GET['jl_media'])) return;
    $id=absint($_GET['jl_media']); $post=get_post($id);
    if(!$post || $post->post_type!=='jl_item' || !jl_visible($post)) {status_header(404);nocache_headers();exit;}
    $size=isset($_GET['size'])&&$_GET['size']==='thumb'?'thumb':'full';
    $key=get_post_meta($id,'_jl_'.$size,true) ?: get_post_meta($id,'_jl_file',true); $dir=jl_storage();
    if(is_wp_error($dir) || !$key || basename($key)!==$key || !is_file($dir.'/'.$key)) {status_header(404);exit;}
    $file=$dir.'/'.$key; $length=filesize($file); $start=0; $end=$length-1;
    nocache_headers(); header('Cache-Control: private, no-store'); header('X-Content-Type-Options: nosniff'); header('Cross-Origin-Resource-Policy: same-origin'); header('Content-Type: '.get_post_meta($id,'_jl_mime',true));header('Accept-Ranges: bytes');
    if(isset($_SERVER['HTTP_RANGE'])) {
        $range=$_SERVER['HTTP_RANGE'];
        if(!preg_match('/^bytes=(\d*)-(\d*)$/',$range,$m) || ($m[1]===''&&$m[2]==='')) {status_header(416);header('Content-Range: bytes */'.$length);exit;}
        if($m[1]==='') {$start=max(0,$length-(int)$m[2]);} else {$start=(int)$m[1];$end=$m[2]===''?$end:min($end,(int)$m[2]);}
        if($start>$end || $start>=$length) {status_header(416);header('Content-Range: bytes */'.$length);exit;}
        status_header(206);header("Content-Range: bytes $start-$end/$length");
    }
    header('Content-Length: '.($end-$start+1));
    if(($_SERVER['REQUEST_METHOD']??'GET')==='HEAD') exit;
    while(ob_get_level()) ob_end_clean(); $handle=fopen($file,'rb'); fseek($handle,$start); $remaining=$end-$start+1;
    while($remaining>0 && !feof($handle)) {$chunk=fread($handle,min(65536,$remaining));if($chunk===false || $chunk==='')break;echo $chunk;$remaining-=strlen($chunk);}
    fclose($handle);exit;
},-10);
add_action('before_delete_post',function($id){
    if(get_post_type($id)!=='jl_item') return; $dir=jl_storage();if(is_wp_error($dir))return;
    foreach(['_jl_file','_jl_full','_jl_thumb'] as $field) {$key=get_post_meta($id,$field,true);if($key && basename($key)===$key && is_file($dir.'/'.$key)) unlink($dir.'/'.$key);}
});
