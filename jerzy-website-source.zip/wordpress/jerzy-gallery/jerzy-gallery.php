<?php
/**
 * Plugin Name: Jerzy Gallery
 * Description: Bilingual personal albums, protected media, guest submissions and photo comments.
 * Version: 1.0.0
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/core.php';
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/actions.php';
require_once __DIR__ . '/includes/admin.php';
register_activation_hook(__FILE__, 'jl_activate');
