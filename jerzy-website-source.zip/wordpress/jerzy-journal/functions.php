<?php
defined('ABSPATH') || exit;
add_action('after_setup_theme',function(){add_theme_support('title-tag');add_theme_support('post-thumbnails');add_theme_support('responsive-embeds');add_theme_support('html5',['comment-form','comment-list','gallery','caption','style','script']);});
add_action('wp_enqueue_scripts',function(){
    foreach(['base','hybrid','cinematic','guest','home-type','accessibility','production'] as $name)wp_enqueue_style('jerzy-'.$name,get_template_directory_uri().'/assets/'.$name.'.css',[], '1.0.0');
    wp_enqueue_script('jerzy-gallery',get_template_directory_uri().'/assets/site.js',[], '1.0.0',true);
});
add_filter('language_attributes',function($attributes){return function_exists('jl_lang')?'lang="'.jl_lang().'"':$attributes;});
function jerzy_text($en,$pl){echo esc_html(jl_t($en,$pl));}
function jerzy_empty($en,$pl){echo '<div class="empty-state"><span aria-hidden="true">＋</span><p>'.esc_html(jl_t($en,$pl)).'</p></div>';}
function jerzy_album_cards($type='photos') {
    foreach(jl_albums() as $a) {
        $cover=jl_cover($a);$items=jl_items($a->ID,$type==='photos'?'photo':($type==='videos'?'video':''));
        echo '<a class="photo country-card" data-search="'.esc_attr(strtolower(jl_title($a))).'" href="'.esc_url(jl_link($type,$a->ID)).'"><div class="countrycover">';
        if($cover)echo '<img src="'.esc_url($cover).'" alt="" loading="lazy" width="900" height="600">';else echo '<div class="cover-placeholder" aria-hidden="true"></div>';
        if($type==='videos')echo '<span class="video-badge" aria-hidden="true">▶</span>';
        echo '</div><div class="countrymeta"><h3>'.esc_html(jl_title($a)).'</h3><span aria-hidden="true">↗</span></div><p>'.esc_html(jl_t('Moments: ','Wspomnienia: ')).count($items).($a->post_status!=='publish'?' · '.esc_html($a->post_status):'').'</p></a>';
    }
}
function jerzy_media_cards($items) {
    foreach($items as $p) {
        $photo=get_post_meta($p->ID,'_jl_kind',true)==='photo';$poster=absint(get_post_meta($p->ID,'_jl_poster',true));
        echo '<a class="photo media-card" data-search="'.esc_attr(jl_title($p).' '.get_post_meta($p->ID,'_jl_category',true)).'" href="'.esc_url(jl_link('media',$p->ID)).'" '.($photo?'data-lightbox="'.esc_url(jl_file_url($p->ID)).'" data-title="'.esc_attr(jl_title($p)).'"':'').'><div class="countrycover">';
        if($photo)echo '<img src="'.esc_url(jl_file_url($p->ID,'thumb')).'" alt="'.esc_attr(jl_title($p)).'" loading="lazy" width="900" height="600">';
        elseif($poster && jl_visible($poster))echo '<img src="'.esc_url(jl_file_url($poster,'thumb')).'" alt="" loading="lazy" width="900" height="600">';
        else echo '<div class="cover-placeholder film-placeholder" aria-hidden="true">▶</div>';
        if(!$photo)echo '<span class="video-badge" aria-hidden="true">▶</span>';
        echo '</div><h3>'.esc_html(jl_title($p)).'</h3><p>'.esc_html(get_post_meta($p->ID,'_jl_category',true)).'</p></a>';
    }
}
function jerzy_media_page($p) {
    $photo=get_post_meta($p->ID,'_jl_kind',true)==='photo';$album=get_post($p->post_parent);
    echo '<div class="pagehead"><a class="textlink" href="'.esc_url(jl_link($photo?'photos':'videos',$album?$album->ID:0)).'">← '.esc_html($album?jl_title($album):jl_t('All galleries','Wszystkie galerie')).'</a><h1>'.esc_html(jl_title($p)).'</h1></div>';
    if($p->post_status!=='publish')echo '<p class="owner-notice">'.esc_html(jl_t('Owner preview — this item is not public.','Podgląd właściciela — ten materiał nie jest publiczny.')).'</p>';
    if($photo)echo '<a data-lightbox="'.esc_url(jl_file_url($p->ID)).'" data-title="'.esc_attr(jl_title($p)).'" href="'.esc_url(jl_file_url($p->ID)).'"><img class="detail-media" src="'.esc_url(jl_file_url($p->ID)).'" alt="'.esc_attr(jl_title($p)).'"></a>';
    elseif($embed=get_post_meta($p->ID,'_jl_embed',true))echo '<iframe class="detail-media" src="'.esc_url($embed).'" title="'.esc_attr(jl_title($p)).'" allow="fullscreen; picture-in-picture" allowfullscreen loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>';
    else { $poster=(int)get_post_meta($p->ID,'_jl_poster',true); echo '<video class="detail-media" controls playsinline preload="metadata" '.($poster&&jl_visible($poster)?'poster="'.esc_url(jl_file_url($poster)).'"':'').' src="'.esc_url(jl_file_url($p->ID)).'"></video>'; }
    echo '<div class="media-caption">'.wp_kses_post(wpautop(jl_body($p))).'</div>';
    if(get_post_meta($p->ID,'_jl_guest',true))echo '<p>'.esc_html(jl_t('Shared by ','Autor: ').get_post_meta($p->ID,'_jl_guest_name',true)).'</p>';
    if(!$photo)return;
    echo '<section class="photo-comments" id="comments"><h2>'.esc_html(jl_t('Under this photograph','Pod tym zdjęciem')).'</h2>';
    $comments=get_comments(['post_id'=>$p->ID,'status'=>'approve','order'=>'ASC','number'=>100]);
    if(!$comments)echo '<p>'.esc_html(jl_t('Be the first to share a thought.','Podziel się pierwszym komentarzem.')).'</p>';
    foreach($comments as $c)echo '<article class="comment-entry"><strong>'.esc_html($c->comment_author).'</strong><p>'.nl2br(esc_html($c->comment_content)).'</p></article>';
    if(isset($_GET['comment_sent']))echo '<p class="success" role="status">'.esc_html(jl_t('Thank you. Your comment is waiting for review.','Dziękuję. Twój komentarz czeka na zatwierdzenie.')).'</p>';
    if($p->post_status==='publish'){
        echo '<form class="comment-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('jl_comment');echo '<input type="hidden" name="action" value="jl_comment"><input type="hidden" name="media_id" value="'.$p->ID.'"><input type="hidden" name="lang" value="'.jl_lang().'"><div class="honeypot" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div><label>'.esc_html(jl_t('Your name','Twoje imię')).'<input name="visitor_name" required maxlength="60" autocomplete="name"></label><label>'.esc_html(jl_t('Your comment','Twój komentarz')).'<textarea name="comment" rows="4" required maxlength="3000"></textarea></label><button>'.esc_html(jl_t('Send for review','Wyślij do zatwierdzenia')).'</button><p>'.esc_html(jl_t('Comments appear after approval. Please do not include private contact details.','Komentarze pojawiają się po zatwierdzeniu. Nie podawaj prywatnych danych kontaktowych.')).'</p></form>';
    }
    echo '</section>';
}
